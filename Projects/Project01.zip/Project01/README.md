# CS-3910-System_Admin_and_Security
School System Admin &amp; Security

Inside Code Directory;
	- playground.py ========> Code holds a coding enviorment where I played around with networkx and generating graphs. 
	- Project01.ipynb ======> Interactive jupyter notebook that hold the colde as well as observations
	
Inside Outputs Directory;
 	- Project01.html =======> A HTML file to view an instance of the jupyter notebook being ran through with it's output and observations made.
	- Project01.pdf ========> A PDF file to view an instance of the jupyter notebook being ran through with it's output and observations made.   
	- Project_Raw_Code.pdf => There is also included another PDF holding the raw code used for this enviorment. 

